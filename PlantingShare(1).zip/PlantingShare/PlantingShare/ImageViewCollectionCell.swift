//
//  ImageViewCollectionCell.swift
//  PlantingShare
//
//  Created by 김준오 on 25/08/2019.
//  Copyright © 2019 lim. All rights reserved.
//

import UIKit

class ImageViewCollectionCell: NSObject {

}
