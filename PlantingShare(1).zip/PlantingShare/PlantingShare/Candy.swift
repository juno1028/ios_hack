//
//  Candy.swift
//  PlantingShare
//
//  Created by 김준오 on 26/08/2019.
//  Copyright © 2019 lim. All rights reserved.
//

import Foundation

struct Candy {
    let category : String
    let name : String
}
